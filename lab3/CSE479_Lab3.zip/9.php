<?php
$day = "5";

switch ($day) {
    case "1":
        echo "It is Saturday!";
        break;
    case "2":
        echo "It is Sunday!";
        break;
    case "3":
        echo "It is Monday!";
        break;
	case "4":
        echo "It is Tuesday!";
        break;
    case "5":
        echo "It is Wednesday!";
        break;
    case "6":
        echo "It is Thursday!";
        break;
	case "7":
        echo "It is Friday!";
        break;
    default:
        echo "Invalid number!";
}
?>